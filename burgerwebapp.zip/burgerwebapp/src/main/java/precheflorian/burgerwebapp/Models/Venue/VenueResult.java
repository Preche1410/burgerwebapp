package precheflorian.burgerwebapp.Models.Venue;
import lombok.Data;
@Data
public class VenueResult {
    private VenuesResponse response;
}
