package precheflorian.burgerwebapp.Models.Burger;

import lombok.Data;

@Data
public class BurgerResponse {
    private String urlWithBurger;
}
